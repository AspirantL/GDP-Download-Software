#ifndef OBSOPTDLG_H
#define OBSOPTDLG_H

#include <QDialog>

namespace Ui {
class obsOptDlg;
}

class obsOptDlg : public QDialog
{
    Q_OBJECT

public:
    explicit obsOptDlg(QWidget *parent = nullptr);
    ~obsOptDlg();

private:
    Ui::obsOptDlg *ui;
};

#endif // OBSOPTDLG_H
