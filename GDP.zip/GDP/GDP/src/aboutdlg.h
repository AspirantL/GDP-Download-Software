#ifndef ABOUTDLG_H
#define ABOUTDLG_H

#include <QDialog>
#include <QShowEvent>
#include <QtCore>

#define PRGNAME     "GDP-Software"
#define VER_GDP     "1.0"
#define COPYRIGHT_GDP   "Copyright (C) 2022 Likun @cumt\nAll rights reserved."

namespace Ui {
class aboutdlg;
}

class aboutdlg : public QDialog
{
    Q_OBJECT

protected:
    void showEvent(QShowEvent *);

public:
    explicit aboutdlg(QWidget *parent = nullptr);
    ~aboutdlg();

public:
    QString About;

private:
    Ui::aboutdlg *ui;
};

#endif // ABOUTDLG_H
