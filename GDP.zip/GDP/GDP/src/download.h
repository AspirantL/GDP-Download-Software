#ifndef DOWNLOAD_H
#define DOWNLOAD_H

#endif // DOWNLOAD_H

#undef UNICODE
#include <windows.h>
#include <math.h>
#include <cstring>
#include <string>
#include <iostream>
#include <time.h>
#include "minwindef.h"
#include "fileapi.h"
#include "processthreadsapi.h"
#include "synchapi.h"
#include "winerror.h"
#include "winbase.h"

#define MAXSTA  1000
#define MAXURLS 50000
#define MAXURLS_SEL 128
#define MAX_HIST    16
#define DLOPT_FORCE   0x01              /* download option: force download existing */
#define DLOPT_KEEPCMP 0x02              /* download option: keep compressed file */
#define FILEPATHSEP '\\'
#define FTP_LISTING ".listing"      /* FTP listing file */
#define FTP_CMD     "wget"          /* FTP/HTTP command */
#define FTP_TIMEOUT 60              /* FTP/HTTP timeout (s) */
#define FTP_RETRY   3               /* FTP number of retry */
#define FTP_NOFILE  2048            /* FTP error no file */
#define HTTP_NOFILE 1               /* HTTP error no file */
#define FTP_USER   "anonymous"
#define FTP_PWD    "330021666@qq.com"


#define URL_FILE   "../GDP/list/URL_LIST.txt"

using namespace std;

//----------------------------------------------------------------------------------------------------
class gtime_c {
public:

    void setTime(time_t t1) { time=t1;}

    time_t epoch2time(const double *ep);
    time_t gpst2time(const int week, const int dow);
    time_t doy2time(const double year,const double doy);

    void time2epoch(double *ep);
    void time2gpst(int* week, int* dow);
    void time2mjd(int* jd);
    double time2doy();
    double timediff(time_t ti);

private:
    time_t time;
};
//----------------------------------------------------------------------------------------------------
class url_c {
public:
    url_c(){
        for (int i=0;i<MAXURLS_SEL;i++) {
            m_type[i] = new char [32];
            m_url[i]  = new char [1024];
            m_local[i]= new char [1024];
            m_type[i][0]='\0';m_url[i][0]='\0';m_local[i][0]='\0';
        }
        m_number=0;
    }

    ~url_c(){
        for (int i=0; i<MAXURLS_SEL; i++) {
            delete [] m_type[i];
            delete []  m_url[i];
            delete [] m_local[i];
        }
    }

public:
    void readUrls(const char *file,char *source_urls,int flag);
    char* getType(int n);
    int  getNumber();
    int  getUrls(char *urlSource, char **type, char **urls,char **locals, const int n);
private:
    char *m_type[MAXURLS_SEL];      /*data type*/
    char *m_url[MAXURLS_SEL];    /*URL Path*/
    char *m_local[MAXURLS_SEL];       /*local path*/
    int  m_number;
};
//-----------------------------------------------------------------------------------------------------
class paths_c
{
public:
    paths_c(){
        for (int i = 0; i<MAXURLS; i++){
            remot[i] = new char [1024];
            remot[i][0] = '\0';
            local[i] = new char [1024];
            local[i][0] = '\0';
        }
        m_number = 0;m_path[0]='\0';
    }
    ~paths_c(){
        for (int i = 0; i<MAXURLS_SEL; i++){
            delete [] remot[i];
            remot[i] = NULL;
            delete [] local[i];
            local[i] = NULL;
        }
    }
public:
    int   reppath(const char *path, time_t time);
    int   gen_paths(time_t time,time_t time_p, char *url, char *localdir,char *dir,
                    const int nsta, char **stas);
    int   add_path();
    int   getPathNumber();
    char* getLocalPath(int n);
    char* getRemotPath(int n);
    void  compact_paths();
private:
    int   repstr(char *str, const char *pat, const char *rep);
    int   gen_path(time_t time, char *url,const char *sta);

private:
    char m_path[1024];
    char *remot[MAXURLS];
    char *local[MAXURLS];
    int m_number;
};
//-----------------------------------------------------------------------------------------------------

char* parse_str(char *buff,char *str,int nmax);

//------------------------------------------------------------------------------------------------------

//---2022-04-29------------------------------------------------------------------------------------------
/*download function--------------------------------------------------------------------------------------*/
int dl_exec(time_t ts, time_t te, char **urls, int nurl, char **stas, int nsta, char **localdir,
            char *dir, int opt,char *msg, FILE *fp);
int exec_down(paths_c *paths,int number, char *remot_p,int opts,int * n,FILE *fp);
int execcmd_to(const char *cmd);

int readStasFile(const char *file,char **stas);
int readStasList(const char *stalist,char **stas);
extern "C" {
    extern int showmsg(const char *format,...);
}
