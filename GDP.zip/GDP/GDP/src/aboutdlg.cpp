#include "aboutdlg.h"
#include "ui_aboutdlg.h"

aboutdlg::aboutdlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::aboutdlg)
{
    ui->setupUi(this);
}

aboutdlg::~aboutdlg()
{
    delete ui;
}

void aboutdlg::showEvent(QShowEvent *event)
{
    if (event->spontaneous()) return;
    QPixmap icon = {QPixmap(":/images/images/ICON.png")};
    icon.scaled(150,150);
    ui->ICON->setPixmap(icon);
    setWindowTitle("About GDP Download Softwart");
    ui->labelAbout->setText(About);
    ui->labelVersion->setText(QString(tr("with GDP Download Software ver.%1")).arg(VER_GDP));
    ui->labelCopyright->setText(COPYRIGHT_GDP);

}
