#include "viewerdlg.h"
#include "ui_viewerdlg.h"
#include <QFile>
#include <QTextStream>

viewerDlg::viewerDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::viewerDlg)
{
    ui->setupUi(this);
}

viewerDlg::~viewerDlg()
{
    delete ui;
}


bool viewerDlg::Read(const QString &logfile)
{
    if (!logfile.isNull()){
        QFile file(logfile);

        if(!file.open(QFile::ReadOnly|QFile::Text)) return 0;

        QTextStream in(&file);

        ui->viewerEdit->setText(in.readAll());

        return 1;
    }
    return 0;
}
