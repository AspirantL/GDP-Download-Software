#include "download.h"
#include <QDebug>
//--------------------------------------------------------------------------------------------
static const double gpst0[]={1980,1,6,0,0,0};

//--------------------------------------------------------------------------------------------
extern time_t gtime_c::epoch2time(const double *ep)
{
    const int doy[]={1,32,60,91,121,152,182,213,244,274,305,335};
    time_t ti={0};
    int days,sec,year=(int)ep[0],mon=(int)ep[1],day=(int)ep[2];

    if (year<1970||2099<year||mon<1||12<mon) return ti;

    /* leap year if year%4==0 in 1901-2099 */
    days=(year-1970)*365+(year-1969)/4+doy[mon-1]+day-2+(year%4==0&&mon>=3?1:0);
    sec=(int)floor(ep[5]);
    ti=(time_t)days*86400+(int)ep[3]*3600+(int)ep[4]*60+sec;
    return ti;
}
//---------------------------------------------------------------------------------------------
extern void gtime_c::time2epoch(double *ep)
{
    const int mday[]={ /* # of days in a month */
        31,28,31,30,31,30,31,31,30,31,30,31,31,28,31,30,31,30,31,31,30,31,30,31,
        31,29,31,30,31,30,31,31,30,31,30,31,31,28,31,30,31,30,31,31,30,31,30,31
    };
    int days,sec,mon,day;

    /* leap year if year%4==0 in 1901-2099 */
    days=(int)(time/86400);
    sec=(int)(time-(time_t)days*86400);
    for (day=days%1461,mon=0;mon<48;mon++) {
        if (day>=mday[mon]) day-=mday[mon]; else break;
    }
    ep[0]=1970+days/1461*4+mon/12; ep[1]=mon%12+1; ep[2]=day+1;
    ep[3]=sec/3600; ep[4]=sec%3600/60; ep[5]=sec%60;
}
//----------------------------------------------------------------------------------------------
extern void gtime_c::time2gpst(int* week, int* dow)
{
    time_t t0=epoch2time(gpst0);
    time_t sec = time-t0+86400;
    int w=(int)(sec/(86400*7));

    if (week) *week=w;
    if (dow) *dow=(int)((sec/86400)%7);
}
//----------------------------------------------------------------------------------------------
extern double gtime_c::time2doy()
{
    double ep[6];

    time2epoch(ep);
    ep[1]=ep[2]=1.0; ep[3]=ep[4]=ep[5]=0.0;
    return timediff(epoch2time(ep))/86400.0+1.0;
}
/* time difference -------------------------------------------------------------
* difference between time_t
* args   : time_t ti    I   time_t structs
* return : time difference (time-ti) (s)
*-----------------------------------------------------------------------------*/
extern double gtime_c::timediff(time_t ti)
{
    return difftime(time,ti);
}
//------------------------------------------------------------------------------
extern time_t gtime_c::doy2time(const double year,const double doy)
{
    double ep[]={year,1,1,0,0,0};
    time_t t0=epoch2time(ep)+(doy-1)*86400;
    return t0;

}
//---------------------------------------------------------------------------------
extern time_t gtime_c::gpst2time(const int week, const int dow)
{
    time_t t0=epoch2time(gpst0);
    time_t ti=t0+(week*7+dow)*86400;
    return ti;
}
//-2022-04-29----------------------------------------------------------------------


//---------------------------------------------------------------------------------
/*flag ->0 read all data urls, flag ->1 read products urls*/
extern void url_c::readUrls(const char *file,char *source_urls, int flag)
{
    FILE *fp;
    char buff[2048],*p,tmp1[32]={0},tmp2[1024]={0},tmp3[1024]={0},surls[32],eurls[32];
    sprintf(surls,"+!%s",source_urls);
    sprintf(eurls,"-!%s",source_urls);

    if (!(fp=fopen(file,"r"))){
        fprintf(stderr,"options file read error %s\n",file);
        return;
    }
    while (fgets(buff,sizeof(buff),fp)){
        if ((p=strstr(buff,surls))){
            for (int j = 0; j < MAXURLS;j++){
              fgets(buff,sizeof(buff),fp);
              if ((p=strchr(buff,'#'))) *p='\0';
              if ((p=strstr(buff,eurls))) return;
              p=buff;

              if (flag){
                  if (strstr(p,"++PRODUCTS")){
                    flag=0;continue;
                  }
                  else
                      continue;
              }

              p=parse_str(p,tmp1,sizeof(tmp1));
              p=parse_str(p,tmp2,sizeof(tmp2));
              p=parse_str(p,tmp3,sizeof(tmp3));
              if (!*tmp1) continue;

              strcpy( m_type[m_number],  tmp1);
              strcpy(  m_url[m_number],  tmp2);
              strcpy(m_local[m_number++],tmp3);
            }
        }
        else
            continue;
    }
    fclose(fp);


    if (m_number<=0){
        fprintf(stderr,"no url in option file %s\n",file);
        return;
    }
}
//----------------------------------------------------------------------------------
extern char* url_c::getType(int n)
{
    return m_type[n];
}
//----------------------------------------------------------------------------------
extern int url_c::getNumber()
{
    return m_number;
}
//----------------------------------------------------------------------------------
extern int  url_c::getUrls(char *urlSource, char **type, char **urls,char **locals, const int tnumber)
{
    int n=0;
    readUrls(URL_FILE,urlSource,0);
    for (int i = 0; i < tnumber; i++){
        for (int j = 0; j < m_number; j++){
            if ((strstr(m_type[j],type[i]))){
                strcpy(  urls[n  ],m_url[j]);
                strcpy(locals[n++],m_local[j]);
                break;
            }
        }
    }
    return n;
}
//----------------------------------------------------------------------------------
/*parse field strings separated by spaces -----------------------------------*/
/*modified separated by spaces and tab  2022-04-27---------------------------*/
extern char* parse_str(char* buff,char* str,int nmax)
{
    char *p,*q,sep[]=" \t\r\n";

    for (p=buff;*p&&(*p==' '||*p=='\t');p++) ;

    if (*p=='"') sep[0]=*p++; /* enclosed within quotation marks */

    for (q=str;*p&&!strchr(sep,*p);p++) {
        if (q<str+nmax-1) *q++=*p;
    }
    *q='\0';
    return *p?p+1:p;
}
//--------------------------------------------------------------------------------------
/* replace keywords in file path -------------------------------------------------------
* replace keywords in file path with date, time, rover and base station id
* args   : char   *path     I   file path (see below)
*          gtime_t time     I   time (gpst)  (time.time==0: not replaced)
* return : status (1:keywords replaced, 0:no valid keyword in the path,
*                  -1:no valid time)
* notes  : the following keywords in path are replaced by date, time and name
*              %Y -> yyyy : year (4 digits) (1900-2099)
*              %y -> yy   : year (2 digits) (00-99)
*              %m -> mm   : month           (01-12)
*              %d -> dd   : day of month    (01-31)
*              %h -> hh   : hours           (00-23)
*              %M -> mm   : minutes         (00-59)
*              %S -> ss   : seconds         (00-59)
*              %n -> ddd  : day of year     (001-366)
*              %W -> wwww : gps week        (0001-9999)
*              %B -> wwww : bds week        (0001-9999)
*              %D -> d    : day of gps week (0-6)
*              %H -> h    : hour code       (a=0,b=1,c=2,...,x=23)
*              %ha-> hh   : 3 hours         (00,03,06,...,21)
*              %hb-> hh   : 6 hours         (00,06,12,18)
*              %hc-> hh   : 12 hours        (00,12)
*              %t -> mm   : 15 minutes      (00,15,30,45)
*              %r -> rrrr : rover id
*              %b -> bbbb : base station id
*-----------------------------------------------------------------------------*/
extern int paths_c::reppath(const char *path,  time_t time)
{
    double ep[6];
    int week,dow,doy,stat=0,bweek;
    char rep[64];
    gtime_c *gt;
    gt = new gtime_c();
    gt->setTime(time);

    strcpy(m_path,path);

    if (!strstr(m_path,"%")) return 0;
    if (time!=0) {
        gt->time2epoch(ep);
        gt->time2gpst(&week,&dow);
        bweek = week-1356;
        doy=gt->time2doy();

        sprintf(rep,"%04.0f",ep[0]);              stat|=repstr(m_path,"%Y",rep);
        sprintf(rep,"%02.0f",fmod(ep[0],100.0));  stat|=repstr(m_path,"%y",rep);
        sprintf(rep,"%02.0f",ep[1]);              stat|=repstr(m_path,"%m",rep);
        sprintf(rep,"%02.0f",ep[2]);              stat|=repstr(m_path,"%d",rep);
        sprintf(rep,"%02.0f",ep[3]);              stat|=repstr(m_path,"%h",rep);
        sprintf(rep,"%03d",  doy);                stat|=repstr(m_path,"%n",rep);
        sprintf(rep,"%04d",  week);               stat|=repstr(m_path,"%W",rep);
        sprintf(rep,"%04d", bweek);               stat|=repstr(m_path,"%B",rep);
        sprintf(rep,"%d",    dow);                stat|=repstr(m_path,"%D",rep);
        sprintf(rep,"%c",    'a'+(int)ep[3]);     stat|=repstr(m_path,"%H",rep);
        sprintf(rep,"%02d",  ((int)ep[4]/15)*15); stat|=repstr(m_path,"%t",rep);
    }
    else if (strstr(m_path,"%Y" )||strstr(m_path,"%y" )||strstr(m_path,"%m" )||
             strstr(m_path,"%d" )||strstr(m_path,"%h" )||strstr(m_path,"%B") ||
             strstr(m_path,"%S" )||strstr(m_path,"%n" )||strstr(m_path,"%W" )||
             strstr(m_path,"%D" )||strstr(m_path,"%H" )||strstr(m_path,"%t" )) {
        return -1; /* no valid time */
    }
    delete gt;
    return stat;
}
//--------------------------------------------------------------------------------------
extern int paths_c::repstr(char *str, const char *pat, const char *rep)
{
    int len=(int)strlen(pat);
    char buff[1024]={'\0'},*p,*q,*r;

    for (p=str,r=buff;*p;p=q+len) {
        if (!(q=strstr(p,pat))) break;
        strncpy(r,p,q-p);
        r+=q-p;
        r+=sprintf(r,"%s",rep);
    }
    if (p<=str) return 0;
    strcpy(r,p);
    strcpy(str,buff);
    return 1;
}
//----------------------------------------------------------------------------------------------------------
extern int paths_c::gen_paths(time_t time, time_t time_p, char *url, char *localdir, char *dir, const int nsta,
                              char **stas)
{
    //time to utc time
    time += 8*3600;
    char *Dir;
    Dir = new char [1024];
    strcpy(Dir,dir);
    if (!*dir) Dir=localdir;
    else strcat(Dir,localdir+12);

    if ((strstr(url,"%s") || strstr(url,"%S")) && (strstr(url,"%h") || strstr(url,"%H"))){
        for (int t=0;t<24;t++){
            for (int i = 0; i < nsta; i++){
                gen_path(time+t*3600,url,stas[i]);
                gen_path(time+t*3600,Dir,stas[i]);
                if (time_p+t*3600){
                    gen_path(time_p+t*3600,url,stas[i]);
                    if (!strcmp(remot[m_number-24],m_path)) {
                       remot[m_number-1][0]='\0';
                       local[--m_number][0]='\0';
                       return 1;
                    }
                }
            }
        }

    }
    else if(strstr(url,"%s") || strstr(url,"%S")){
        for (int i = 0; i < nsta; i++){
            gen_path(time,url,stas[i]);
            gen_path(time,Dir,stas[i]);
            if (time_p){
                gen_path(time_p,url,stas[i]);
                if (!strcmp(remot[m_number-1],m_path)) {
                   remot[m_number-1][0]='\0';
                   local[--m_number][0]='\0';
                   return 1;
                }
            }
        }
    }

    else{
        gen_path(time,url,"");
        gen_path(time,Dir,"");
        if (time_p){
            gen_path(time_p,url,"");
            if (!strcmp(remot[m_number-1],m_path)){
                remot[m_number-1][0]='\0';
                local[--m_number][0]='\0';
                return 1;
            }

        }
    }
    delete Dir;
    dir=NULL;
    return 1;
}
//----------------------------------------------------------------------------------------------------------
extern int paths_c::gen_path(time_t time, char *url, const char *sta)
{
    char buff[1024],*p,*q;
    char l_name[1024]="",u_name[1024]="";

    for (p=l_name,q=(char *)sta;(*p=(char)tolower(*q));p++,q++);
    for (p=u_name,q=(char *)sta;(*p=(char)toupper(*q));p++,q++);

    for (p=buff,q=(char *)url;(*p=*q);p++,q++){
        if (*q=='%') q++; else continue;
        if      (*q=='s' || *q=='r') p+=sprintf(p,"%s",l_name)-1;
        else if (*q=='S' || *q=='R') p+=sprintf(p,"%s",u_name)-1;
        else     q--;
    }
    reppath(buff,time);
    if (!add_path()) return 0;
    return 1;
}
//----------------------------------------------------------------------------------------------------------
extern int paths_c::add_path()
{
    int urlflag=0;
    if (m_number > MAXURLS) return 0;

    if      (!strncmp(m_path,"ftp://"  ,6)) urlflag=1;
    else if (!strncmp(m_path,"ftps://" ,7)) urlflag=1;
    else if (!strncmp(m_path,"http://" ,7)) urlflag=1;
    else if (!strncmp(m_path,"https://",8)) urlflag=1;
    else urlflag=0;

    if (urlflag){
        strcpy(remot[m_number],m_path);
    }
    else{
        strcpy(local[m_number++],m_path);
    }
    return 1;
}
//----------------------------------------------------------------------------------------------------------
extern void paths_c::compact_paths()
{
    for (int i=0;i<m_number;i++){
        for (int j=i+1;j<m_number;j++){
            if (strcmp(remot[i],remot[j])) continue;
            delete [] remot[j];
            delete [] local[j];
            for(int k=j;k<m_number-1;k++) {
               remot[k]=remot[k+1];
               local[k]=local[k+1];
            }
            m_number--;j--;
        }
    }
}
//----------------------------------------------------------------------------------------------------------
extern int paths_c::getPathNumber()
{
    return m_number;
}
//----------------------------------------------------------------------------------------------------------
extern char* paths_c::getRemotPath(int n)
{
    return  remot[n];
}
//---------------------------------------------------------------------------------------------------------
extern char* paths_c::getLocalPath(int n)
{
    return local[n];
}
//----------------------------------------------------------------------------------------------------------
/*download function--------------------------------------------------------------------------------------*/
extern int dl_exec(time_t ts, time_t te, char **urls, int nurl, char **stas, int nsta,
                   char **localdir,char *dir, int opt,char *msg, FILE *fp)
{
    paths_c *paths; paths = new paths_c();
    time_t ts_p=0;
    char remot_p[1024]="";
    int i,n[4]={0};
    clock_t tick = clock();

    /*generate download paths  */
    while (difftime(ts,te)<1E-3){

        for (i=0;i<nurl;i++){
            if (!paths->gen_paths(ts,ts_p,urls[i],localdir[i],dir,nsta,stas)){
                delete paths;
                sprintf(msg,"too many download files");
                return 0;
            }
        }
        ts_p=ts; ts=ts+86400;
    }
    /*compact download paths*/
    paths->compact_paths();

    if (paths->getPathNumber()<=0){
        sprintf(msg,"no download data");
        return 0;
    }

    for (i=0;i<paths->getPathNumber();i++){
        if (exec_down(paths,i,remot_p, opt,n,fp)) break;
    }

    sprintf(msg,"OK=%d No_File=%d Error=%d (Time=%.1f s)",n[0],n[1],
            n[3],(clock()-tick)*0.001);

    delete paths;
    return 1;
}
//--------------------------------------------------------------------------------------------------------------------------
static int get_list(const char *url)
{
    FILE *fp;
    char *p,cmd[4096];
    char *list_url;
    list_url = new char [1024];
    strcpy(list_url,url);
    remove(FTP_LISTING);
    if((p=strrchr(list_url,'/'))) strcpy(p+1,""); else return 0;

    sprintf(cmd,"%s %s --ftp-user=%s --ftp-password=%s --glob=off"
            "--passive-ftp --no-remove-listing -N -t 1 -T %d\n",
            FTP_CMD,list_url,FTP_USER,FTP_PWD,FTP_TIMEOUT);

    execcmd_to(cmd);

    if (!(fp=fopen(FTP_LISTING,"r"))) return 0;
    fclose(fp);
    delete list_url;
    return 1;
}
/* compare str1 and str2 with wildcards (*) ----------------------------------*/
static int cmp_str(const char *str1, const char *str2)
{
    char s1[1026],s2[1026],*p,*q;

    sprintf(s1,"^%s$",str1);
    sprintf(s2,"^%s$",str2);

    for (p=s1,q=strtok(s2,"*");q;q=strtok(NULL,"*")) {
        if ((p=strstr(p,q))) p+=strlen(q); else break;
    }
    return p!=NULL;
}
/* test file in remote file list ---------------------------------------------*/
static int test_list(paths_c *paths,int number)
{
    FILE *fp;
    char buff[1024],*file,*list,*p;
    int i;

    if (!(fp=fopen(FTP_LISTING,"r"))) return 1;

    if ((p=strrchr(paths->getRemotPath(number),'/'))) file=p+1; else return 1;

    /* search file in remote file list */
    while (fgets(buff,sizeof(buff),fp)) {

        /* remove symbolic link */
        if ((p=strstr(buff,"->"))) *p='\0';

        for (i=strlen(buff)-1;i>=0;i--) {
            if (strchr(" \r\n",buff[i])) buff[i]='\0'; else break;
        }
        /* file as last field */
        if ((p=strrchr(buff,' '))) list=p+1; else list=buff;

        if (!strcmp(file,list)) {
            fclose(fp);
            return 1;
        }
        /* compare with wild-card (*) */
        if (cmp_str(list,file)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}
/* generate local directory recursively --------------------------------------*/
static int mkdir_r(const char *dir)
{
    char pdir[1024],*p;

#ifdef WIN32
    HANDLE h;
    WIN32_FIND_DATA data;

    if (!*dir||!strcmp(dir+1,":\\")) return 1;

    strcpy(pdir,dir);
    if ((p=strrchr(pdir,FILEPATHSEP))) {
        *p='\0';
        h=FindFirstFile(pdir,&data);
        if (h==INVALID_HANDLE_VALUE) {
            if (!mkdir_r(pdir)) return 0;
        }
        else FindClose(h);
    }
    if (CreateDirectory(dir,NULL)||
        GetLastError()==ERROR_ALREADY_EXISTS) return 1;
    return 0;
#else
    FILE *fp;

    if (!*dir) return 1;

    strcpy(pdir,dir);
    if ((p=strrchr(pdir,FILEPATHSEP))) {
        *p='\0';
        if (!(fp=fopen(pdir,"r"))) {
            if (!mkdir_r(pdir)) return 0;
        }
        else fclose(fp);
    }
    if (!mkdir(dir,0777)||errno==EEXIST) return 1;

    return 0;
#endif
}
//---------------------------------------------------------------------------------------------------------------------
extern int execcmd(const char *cmd)
{
#ifdef WIN32
    PROCESS_INFORMATION info;
    STARTUPINFO si={0};
    DWORD stat;
    char cmds[1024];

    si.cb=sizeof(si);
    sprintf(cmds,"cmd /c %s",cmd);
    if (!CreateProcess(NULL,(LPTSTR)cmds,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,
                       NULL,&si,&info)) return -1;
    WaitForSingleObject(info.hProcess,INFINITE);
    if (!GetExitCodeProcess(info.hProcess,&stat)) stat=-1;
    CloseHandle(info.hProcess);
    CloseHandle(info.hThread);
    return (int)stat;
#else
    trace(3,"execcmd: cmd=%s\n",cmd);

    return system(cmd);
#endif
}
//--------------------------------------------------------------------------------------------------------------------------
static int gdp_uncompress(const char *file, char *uncfile)
{
    int stat=0;
    char *p,cmd[64+2048]="",tmpfile[1024]="",buff[1024],*fname,*dir="";

    strcpy(tmpfile,file);
    if (!(p=strrchr(tmpfile,'.'))) return 0;

    /* uncompress by gzip */
    if (!strcmp(p,".z"  )||!strcmp(p,".Z"  )||
        !strcmp(p,".gz" )||!strcmp(p,".GZ" )||
        !strcmp(p,".zip")||!strcmp(p,".ZIP")) {

        strcpy(uncfile,tmpfile); uncfile[p-tmpfile]='\0';
        sprintf(cmd,"gzip -f -d -c \"%s\" > \"%s\"",tmpfile,uncfile);

        if (execcmd(cmd)) {
            remove(uncfile);
            return -1;
        }
        strcpy(tmpfile,uncfile);
        stat=1;
    }
    /* extract tar file */
    if ((p=strrchr(tmpfile,'.'))&&!strcmp(p,".tar")) {

        strcpy(uncfile,tmpfile); uncfile[p-tmpfile]='\0';
        strcpy(buff,tmpfile);
        fname=buff;
#ifdef WIN32
        if ((p=strrchr(buff,'\\'))) {
            *p='\0'; dir=fname; fname=p+1;
        }
        sprintf(cmd,"set PATH=%%CD%%;%%PATH%% & cd /D \"%s\" & tar -xf \"%s\"",
                dir,fname);
#else
        if ((p=strrchr(buff,'/'))) {
            *p='\0'; dir=fname; fname=p+1;
        }
        sprintf(cmd,"tar -C \"%s\" -xf \"%s\"",dir,tmpfile);
#endif
        if (execcmd(cmd)) {
            if (stat) remove(tmpfile);
            return -1;
        }
        if (stat) remove(tmpfile);
        stat=1;
    }
    /* extract hatanaka-compressed file by cnx2rnx */
    else if ((p=strrchr(tmpfile,'.'))&&
             ((strlen(p)>3&&(*(p+3)=='d'||*(p+3)=='D'))||
              !strcmp(p,".crx")||!strcmp(p,".CRX"))) {

        strcpy(uncfile,tmpfile);
        uncfile[p-tmpfile+3]=*(p+3)=='D'?'O':'o';
        sprintf(cmd,"crx2rnx < \"%s\" > \"%s\"",tmpfile,uncfile);

        if (execcmd(cmd)) {
            remove(uncfile);
            if (stat) remove(tmpfile);
            return -1;
        }
        if (stat) remove(tmpfile);
        stat=1;
    }
    return stat;
}
//---------------------------------------------------------------------------------------------------------------------
extern int exec_down(paths_c *paths,int number,char *remot_p, int opts,int *n,FILE *fp)
{
    char *p,*ofile,dir[1024],opt1[32]={0},errfile[1024],cmd[4096],tmpfile[1024],buff[2048];
    int ret,proto;

    strcpy(dir,paths->getLocalPath(number));
    //if ((p=strrchr(dir,FILEPATHSEP))) *p='\0';

    if      (!strncmp(paths->getRemotPath(number),"ftp://"  ,6)) proto=0;
    else if (!strncmp(paths->getRemotPath(number),"ftps://" ,7)) proto=2;
    else if (!strncmp(paths->getRemotPath(number),"http://" ,7)) proto=1;
    else if (!strncmp(paths->getRemotPath(number),"https://",8)) proto=1;
    else {
        if (fp) fprintf(fp,"%s ERROR (INVALID PATH)\n",paths->getRemotPath(number));
        n[1]++;
        return 0;
    }
    /* test local file existence*/
    if ((opts&DLOPT_FORCE)){
        strcpy(opt1,"-nc");
    }
    /* get remote file list for FTP or FTPS */
    if ((proto==0||proto==2)&&(p=strrchr(paths->getRemotPath(number),'/'))&&
        strncmp(paths->getRemotPath(number),remot_p,p-paths->getRemotPath(number))) {

        if (get_list(paths->getRemotPath(number))) {
            strcpy(remot_p,paths->getRemotPath(number));
        }
    }

    /* test file in listing for FTP or FTPS or extend wild-card in file path */
    if ((proto==0||proto==2)&&!test_list(paths,number)) {

        if (fp) fprintf(fp,"%s NO_FILE\n",paths->getRemotPath(number));
        n[1]++;
        return 0;
    }

    /* generate local directory recursively */
    if (!mkdir_r(dir)) {
        if (fp) fprintf(fp,"%s -> %s ERROR (LOCAL DIR)\n",paths->getRemotPath(number),dir);
        n[3]++;
        return 0;
    }


    /* download command */
    sprintf(errfile,"%s.log",paths->getLocalPath(number));
    strcpy(buff,paths->getRemotPath(number));
    ofile=buff;
    if((p=strrchr(buff,'/'))){
        sprintf(ofile,"%s\\%s",paths->getLocalPath(number),p+1);
    }
    if (proto==0||proto==2) {
        sprintf(cmd,"%s %s --ftp-user=%s --ftp-password=%s  "
                "--passive-ftp %s -t %d -T %d  -O \"%s\" -a \"%s\"\n",
                FTP_CMD,paths->getRemotPath(number),FTP_USER,FTP_PWD,opt1,FTP_RETRY,FTP_TIMEOUT,
                ofile,errfile);
    }
    else {
        sprintf(cmd,"%s %s --http-user=%s --http-password=%s s-t %d -T %d -O \"%s\" -a \"%s\" \n",
                FTP_CMD,paths->getRemotPath(number),FTP_USER,FTP_PWD,FTP_RETRY,FTP_TIMEOUT,
                ofile,errfile);
    }
    if (fp) fprintf(fp,"%s -> %s",paths->getRemotPath(number),dir);

    /* execute download command */
    if ((ret=execcmd_to(cmd))) {
        if ((proto==0&&ret==FTP_NOFILE)||
            (proto==1&&ret==HTTP_NOFILE)) {
            if (fp) fprintf(fp," NO_FILE\n");
            n[1]++;
        }
        else {
            if (fp) fprintf(fp," ERROR (%d)\n",ret);
            n[3]++;
        }
        remove(ofile);
        return ret==2;
    }
    //remove(errfile);

    /* uncompress download file */
    if ((opts&DLOPT_KEEPCMP)&&(p=strrchr(ofile,'.'))&&
        (!strcmp(p,".z")||!strcmp(p,".gz")||!strcmp(p,".zip")||
         !strcmp(p,".Z")||!strcmp(p,".GZ")||!strcmp(p,".ZIP"))) {

        if (gdp_uncompress(ofile,tmpfile)) {
            remove(ofile);
        }
        else {
            if (fp) fprintf(fp," ERROR (UNCOMP)\n");
            n[3]++;
            return 0;
        }
    }
    if (fp) fprintf(fp," OK\n");
    n[0]++;
    return 0;

}

/* execute command with test timeout -----------------------------------------*/
extern int execcmd_to(const char *cmd)
{
#ifdef WIN32
    PROCESS_INFORMATION info;
    STARTUPINFO si={0};
    DWORD stat;
    char cmds[4096];

    si.cb=sizeof(si);
    sprintf(cmds,"cmd /c %s",cmd);
    if (!CreateProcess(NULL,(LPTSTR)cmds,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,
                       NULL,&si,&info)) return -1;

    while (WaitForSingleObject(info.hProcess,10)==WAIT_TIMEOUT) {
    }
    if (!GetExitCodeProcess(info.hProcess,&stat)) stat=-1;
    CloseHandle(info.hProcess);
    CloseHandle(info.hThread);
    return (int)stat;
#else
    return system(cmd);
#endif
}
extern int readStasFile(const char *file,char **stas)
{
    FILE *fp;
    char buff[4096],*p;
    int n=0;

    if (!(fp=fopen(file,"r"))) {
        fprintf(stderr,"station list file read error %s\n",file);
        return 0;
    }

    while (fgets(buff,sizeof(buff),fp)&&n<MAXSTA){
        if ((p=strchr(buff,'#'))) *p='\0';
        for(p=strtok(buff," \t\r\n");p&&n<MAXSTA;p=strtok(NULL," \t\r\n")){
            strcpy(stas[n++],p);
        }
    }

    fclose(fp);

    if (n<=0){
        fprintf(stderr,"no station in station list file %s\n",file);
        return 0;
    }
    return n;
}
extern int readStasList(const char *stalist,char **stas)
{
    char buff[4096],*p;
    int n=0;
    if (!strlen(stalist)){
        fprintf (stderr,"no station in list");
        return 0;
    }
    strcpy(buff,stalist);

    for (p=strtok(buff," \t\r\n");p&&n<MAXSTA;p=strtok(NULL," \t\r\n")){
        strcpy(stas[n++],p);
    }

    return n;
}
