#ifndef VIEWERDLG_H
#define VIEWERDLG_H

#include <QDialog>

namespace Ui {
class viewerDlg;
}

class viewerDlg : public QDialog
{
    Q_OBJECT

public:
    explicit viewerDlg(QWidget *parent = nullptr);
    ~viewerDlg();
public:
    bool Read(const QString &file);

private:
    Ui::viewerDlg *ui;
};

#endif // VIEWERDLG_H
