#include "obsoptdlg.h"
#include "ui_obsoptdlg.h"

obsOptDlg::obsOptDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::obsOptDlg)
{
    ui->setupUi(this);
}

obsOptDlg::~obsOptDlg()
{
    delete ui;
}
