#ifndef MAINFORM_H
#define MAINFORM_H

#include <QMainWindow>
#include <QDebug>
#include <QTimer>
#include <QThread>
#include <QSystemTrayIcon>
#include <QCompleter>
#include <QFileSystemModel>
#include <QComboBox>
#include <QDesktopServices>
#include <QUrl>

#include "download.h"
#include "aboutdlg.h"
#include "viewerdlg.h"


class DownloadThread;

QT_BEGIN_NAMESPACE
namespace Ui { class MainForm; }
QT_END_NAMESPACE


class MainForm : public QMainWindow
{
    Q_OBJECT

protected:
    void FormCreate();

public:
    MainForm(QWidget *parent = nullptr);
    ~MainForm();

public:

public slots:
    void BtnSetDayClick();
    void BtnSetDoyClick();
    void BtnSetWeekClick();
    void BtnAboutClick();
    void BtnTrayClick();
    void TrayIconActivated(QSystemTrayIcon::ActivationReason);
    void BoxLocalDirClick();
    void BtnDownloadClick();
    void BtnCboxStaListClick();
    void BtnListDirClick();
    void TimerTimer();

    void cBoxOBSClick();
    void cBoxSTA_NAVClick();
    void cBoxNAVClick();

    void BtnLocalDirClick();
    void rBtnCDDISClick();
    void rBtnWHUClick();
    void rBtniGMASClick();
    void rBtnCORSClick();
    void rBtnOTHERSClick();
    void BtnAddListClick();
    void BtnRemoveListClick();
    void BtnProductAddClick();
    void BtnProductRemoveClick();

    void rBtnHKClick();
    void rBtnAUClick();
    void BtnCorsAddClick();
    void BtnCorsRemoveClick();
    void BtnLoadCorsListClick();

    void BtnOthersAddClick();
    void BtnOthersRemoveClick();
    void DownloadFinished();

    void BtnLogClick();

private:
    void IniForm();
    void updateEnabled();
    int  selectStas(char **stas);
    void PanelEnable(int ena);
    void LoadProducts(QString file);
    void updateChecked();
    void selectUrls(char **type, char **urls, char **locals, const int n);
    int  getDataType(char **type);

    void AddHist(QComboBox *combo);

    time_t getTime(QDateTime time);
    QPixmap Images[8];
    int TimerCnt;

    viewerDlg *viewerDialog;
    DownloadThread *thread;
    QSystemTrayIcon TrayIcon;

public:
    QString IniFile;
    QString LogFile;
    QTimer  Timer;

private:
    Ui::MainForm *ui;

};
#endif // MAINFORM_H
