#include "GDPmain.h"
#include "ui_GDPmain.h"

#include <QPalette>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QThread>
#include <QDir>
#include <QFileDialog>
#include <QCommandLineParser>
#include <QSettings>
#include <QMetaObject>

static int abortf = 0;

class DownloadThread : public QThread
{
public:
    int nurl, nsta,opts;
    char *urls[MAXURLS_SEL],*stas[MAXSTA],*localdir[MAXURLS_SEL],dir[1024],path[1024],msg[1024];
    time_t ts,te;
    FILE *fp;
    QString LogFile;
    //download *dl;

    explicit DownloadThread(QObject *parent,const QString lf) : QThread(parent)
    {
        nurl = 0;nsta=0;opts=0;
        ts=0;te=0;
        LogFile = lf;
        fp = NULL;
        //dl = new download();

        msg[0] = dir[0] = path[0] = '\0';
        for (int i=0;i<MAXURLS_SEL;i++) {
            urls[i] = new char[1024]; urls[i][0] = '\0';
            localdir[i] = new char[1024];localdir[i][0]='\0';
        }
        for (int i=0;i<MAXSTA;i++){
            stas[i] = new char [16]; stas[i][0] = '\0';
        }

    }
    ~DownloadThread()
    {
        for (int i=0;i<MAXURLS_SEL;i++) {delete [] urls[i];delete [] localdir[i];}
        for (int j=0;j<MAXSTA;j++) delete [] stas[j];
        //delete dl;dl=NULL;
    }
protected:
    void run()
    {
        dl_exec(ts,te,urls,nurl,stas,nsta,localdir,dir,opts,msg,fp);
    }
};

MainForm::MainForm(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainForm)
{
    ui->setupUi(this);
    setlocale(LC_NUMERIC, "C");

    QCompleter *dirCompleter = new QCompleter(this);
    QFileSystemModel *dirModel = new QFileSystemModel(dirCompleter);
    dirModel->setRootPath("");
    dirModel->setFilter(QDir::AllDirs | QDir::Drives | QDir::NoDotAndDotDot);
    dirCompleter->setModel(dirModel);
    ui->LocalDir->setCompleter(dirCompleter);
    ui->CorsListDir->setCompleter(dirCompleter);
    ui->ListDir->setCompleter(dirCompleter);

    connect(ui->BtnSetDay,SIGNAL(clicked(bool)),this,SLOT(BtnSetDayClick()));
    connect(ui->BtnSetDoy,SIGNAL(clicked(bool)),this,SLOT(BtnSetDoyClick()));
    connect(ui->BtnSetWeek,SIGNAL(clicked(bool)),this,SLOT(BtnSetWeekClick()));
    connect(ui->BtnTray, SIGNAL(clicked(bool)), this, SLOT(BtnTrayClick()));
    connect(&TrayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(TrayIconActivated(QSystemTrayIcon::ActivationReason)));
    connect(ui->cBoxStaList,SIGNAL(clicked(bool)),this,SLOT(BtnCboxStaListClick()));
    connect(ui->BtnListDir,SIGNAL(clicked(bool)),this,SLOT(BtnListDirClick()));
    connect(ui->BtnDownload,SIGNAL(clicked(bool)),this,SLOT(BtnDownloadClick()));
    connect(&Timer, SIGNAL(timeout()), this, SLOT(TimerTimer()));

    connect(ui->cBoxLocalDir,SIGNAL(clicked(bool)),this,SLOT(BoxLocalDirClick()));
    connect(ui->BtnLocalDir,SIGNAL(clicked(bool)),this,SLOT(BtnLocalDirClick()));
    connect(ui->BtnAbout,SIGNAL(clicked(bool)),this,SLOT(BtnAboutClick()));
    connect(ui->rBtnCDDIS,SIGNAL(clicked(bool)),this,SLOT(rBtnCDDISClick()));
    connect(ui->rBtniGMAS,SIGNAL(clicked(bool)),this,SLOT(rBtniGMASClick()));
    connect(ui->rBtnWHU,SIGNAL(clicked(bool)),this,SLOT(rBtnWHUClick()));
    connect(ui->rBtnCORS,SIGNAL(clicked(bool)),this,SLOT(rBtnCORSClick()));
    connect(ui->rBtnOTHERS,SIGNAL(clicked(bool)),this,SLOT(rBtnOTHERSClick()));

    connect(ui->cBoxOBS,SIGNAL(clicked(bool)),this,SLOT(cBoxOBSClick()));
    connect(ui->cBoxNav,SIGNAL(clicked(bool)),this,SLOT(cBoxNAVClick()));
    connect(ui->cBoxSTA_NAV,SIGNAL(clicked(bool)),this,SLOT(cBoxSTA_NAVClick()));

    connect(ui->BtnAddList,SIGNAL(clicked(bool)),this,SLOT(BtnAddListClick()));
    connect(ui->BtnRemoveList,SIGNAL(clicked(bool)),this,SLOT(BtnRemoveListClick()));
    connect(ui->BtnProductAdd,SIGNAL(clicked(bool)),this,SLOT(BtnProductAddClick()));
    connect(ui->BtnProductRemove,SIGNAL(clicked(bool)),this,SLOT(BtnProductRemoveClick()));

    connect(ui->rBtnHK,SIGNAL(clicked(bool)),this,SLOT(rBtnHKClick()));
    connect(ui->rBtnAU,SIGNAL(clicked(bool)),this,SLOT(rBtnAUClick()));
    connect(ui->BtnCorsAdd,SIGNAL(clicked(bool)),this,SLOT(BtnCorsAddClick()));
    connect(ui->BtnCorsRemove,SIGNAL(clicked(bool)),this,SLOT(BtnCorsRemoveClick()));
    connect(ui->BtnLoadCorsList,SIGNAL(clicked(bool)),this,SLOT(BtnLoadCorsListClick()));

    connect(ui->BtnOthersAdd,SIGNAL(clicked(bool)),this,SLOT(BtnOthersAddClick()));
    connect(ui->BtnOthersRemove,SIGNAL(clicked(bool)),this,SLOT(BtnOthersRemoveClick()));
    connect(ui->BtnLog,SIGNAL(clicked(bool)),this,SLOT(BtnLogClick()));

    for (int i = 0; i < 8; i++)
        Images[i].load(QString(":/images/images/wait%1.bmp").arg(i+1));

    TimerCnt = 0;

    QSettings setting(IniFile, QSettings::IniFormat);
    LogFile = setting.value("opt/logfile", "").toString();

    TrayIcon.setIcon(QPixmap(":/images/images/logo.png"));
    setWindowIcon(QIcon(":/images/images/logo.png"));

    FormCreate();
}

MainForm::~MainForm()
{
    delete ui;
}


//---------------------------------------------------------------------------
void MainForm::FormCreate()
{
    QString file = QApplication::applicationFilePath();
    QFileInfo fi(file);

    IniFile = fi.absolutePath() + "/" + fi.baseName() + ".ini";

    setWindowTitle(QString("%1 v%2").arg(PRGNAME).arg(VER_GDP));

    QCommandLineParser parser;
    parser.setApplicationDescription("GDP Download Software Qt");
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption iniFileOption(QStringList() << "i" << "ini-file",
                     QCoreApplication::translate("main", "ini file to use"),
                     QCoreApplication::translate("main", "ini file"));
    parser.addOption(iniFileOption);

    QCommandLineOption titleOption(QStringList() << "t" << "title",
                       QCoreApplication::translate("main", "window title"),
                       QCoreApplication::translate("main", "title"));
    parser.addOption(titleOption);

    parser.process(*QApplication::instance());

    if (parser.isSet(iniFileOption))
        IniFile = parser.value(iniFileOption);

    if (parser.isSet(titleOption))
        setWindowTitle(parser.value(titleOption));

    IniForm();
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::IniForm()
{

    ui->dayTime1->setDate(QDate::currentDate());
    ui->dayTime2->setDate(QDate::currentDate());
    BtnSetDayClick();
    ui->rBtnCDDIS->setChecked(true);

    LoadProducts(URL_FILE);
}
//---------------------------------------------------------------------------
void MainForm::BtnSetDayClick()
{
    int week1,dow1,week2,dow2;
    time_t time1,time2;
    gtime_c t1, t2;

    QDateTime TI1(ui->dayTime1->dateTime());
    time1=static_cast<time_t>(TI1.toTime_t());
    QDateTime TI2(ui->dayTime2->dateTime());
    time2=static_cast<time_t>(TI2.toTime_t());

    t1.setTime(time1);t2.setTime(time2);

    t1.time2gpst(&week1,&dow1);t2.time2gpst(&week2,&dow2);

    ui->year1->setValue(TI1.date().year());
    ui->doy1->setValue(TI1.date().dayOfYear());
    ui->week1->setValue(week1);
    ui->dow1->setValue(dow1);

    ui->year2->setValue(TI2.date().year());
    ui->doy2->setValue(TI2.date().dayOfYear());
    ui->week2->setValue(week2);
    ui->dow2->setValue(dow2);

    int n = (time2-time1)/86400 + 1;
    if (n>0)
        ui->BoxDate->setTitle(QString(tr("DATE (selected %1 day)")).arg(n));
    else
        ui->BoxDate->setTitle(QString(tr("DATE (selected 0 day)")));
}
//-------------------------------------------------------------------------
void MainForm::BtnSetDoyClick()
{
    double ep1[6],ep2[6];
    int week1,dow1,week2,dow2;
    time_t time1,time2; gtime_c t1,t2;

    double year1 = ui->year1->value();
    double doy1  = ui->doy1->value();
    double year2 = ui->year2->value();
    double doy2  = ui->doy2->value();

    time1=t1.doy2time(year1,doy1);
    time2=t1.doy2time(year2,doy2);
    t1.setTime(time1);t2.setTime(time2);

    t1.time2epoch(ep1);t2.time2epoch(ep2);
    t1.time2gpst(&week1,&dow1);t2.time2gpst(&week2,&dow2);

    ui->dayTime1->setDate(QDate((int)ep1[0],(int)ep1[1],(int)ep1[2]));
    ui->week1->setValue(week1);
    ui->dow1->setValue(dow1);
    ui->dayTime2->setDate(QDate((int)ep2[0],(int)ep2[1],(int)ep2[2]));
    ui->week2->setValue(week2);
    ui->dow2->setValue(dow2);

    int n = (time2-time1)/86400 + 1;
    if (n>0)
        ui->BoxDate->setTitle(QString(tr("DATE (selected %1 day)")).arg(n));
    else
        ui->BoxDate->setTitle(QString(tr("DATE (selected 0 day)")));
}
//--------------------------------------------------------------------------
void MainForm::BtnSetWeekClick()
{
    double doy1, doy2, ep1[6], ep2[6];
    time_t time1,time2;gtime_c t1,t2;

    int week1 = ui->week1->value();
    int dow1  = ui->dow1->value();
    int week2 = ui->week2->value();
    int dow2  = ui->dow2->value();

    time1=t1.gpst2time(week1,dow1);time2=t2.gpst2time(week2,dow2);
    t1.setTime(time1);t2.setTime(time2);
    doy1=t1.time2doy();doy2=t2.time2doy();
    t1.time2epoch(ep1);t2.time2epoch(ep2);

   ui->dayTime1->setDate(QDate((int)ep1[0],(int)ep1[1],(int)ep1[2]));
   ui->year1->setValue((int)ep1[0]);
   ui->doy1->setValue((int)doy1);
   ui->dayTime2->setDate(QDate((int)ep2[0],(int)ep2[1],(int)ep2[2]));
   ui->year2->setValue((int)ep2[0]);
   ui->doy2->setValue((int)doy2);

   int n = (time2-time1)/86400 + 1;
   if (n>0)
       ui->BoxDate->setTitle(QString(tr("DATE (selected %1 day)")).arg(n));
   else
       ui->BoxDate->setTitle(QString(tr("DATE (selected 0 day)")));
}
//---------------------------------------------------------------------------
void MainForm::BoxLocalDirClick()
{
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::BtnCboxStaListClick()
{
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtnCDDISClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtnWHUClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtniGMASClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtnCORSClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtnOTHERSClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::rBtnHKClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
}
//---------------------------------------------------------------------------
void MainForm::rBtnAUClick()
{
    updateChecked();
    LoadProducts(URL_FILE);
}
//---------------------------------------------------------------------------
void MainForm::cBoxNAVClick()
{
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::cBoxOBSClick()
{
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::cBoxSTA_NAVClick()
{
    updateEnabled();
}
//---------------------------------------------------------------------------
void MainForm::updateChecked()
{
    ui->DataList->clear();
    ui->ProductsSourceList->clear();ui->ProductsDownloadList->clear();
    ui->CorsSourceList->clear();ui->CorsDownloadList->clear();
    ui->OthersSourceList->clear();ui->OthersDownloadList->clear();
    ui->cBoxOBS->setChecked(false);
    ui->cBoxNav->setChecked(false);
    ui->cBoxSTA_NAV->setChecked(false);
    ui->cBoxStaList->setChecked(false);
}

//---------------------------------------------------------------------------
void MainForm::LoadProducts(QString file)
{
    url_c *URL; URL = new url_c();
    char *sourceurl = new char [32];
    char *p;
    sourceurl[0]='\0';
    int productsFlag=1;

    if (ui->rBtnCDDIS->isChecked())
        strcpy(sourceurl,"CDDIS");
    else if(ui->rBtnWHU->isChecked())
        strcpy(sourceurl,"WHU");
    else if(ui->rBtniGMAS->isChecked())
        strcpy(sourceurl,"iGMAS");
    else if (ui->rBtnCORS->isChecked()){
        strcpy(sourceurl,"CORS");
        productsFlag = 0;
    }
    else if (ui->rBtnOTHERS->isChecked()){
        strcpy(sourceurl,"OTHERS");
        productsFlag = 0;
    }

    URL->readUrls(qPrintable(file),sourceurl,productsFlag);

    if (productsFlag){
        for (int i = 0; i < URL->getNumber(); i++){
            ui->ProductsSourceList->addItem(URL->getType(i));
        }
    }
    else if ((strstr(sourceurl,"CORS"))){
        if (ui->rBtnAU->isChecked()){
            for (int i = 0; i < URL->getNumber(); i++){
                if((p=strstr(URL->getType(i),"AU")))
                    ui->CorsSourceList->addItem(URL->getType(i));
            }
        }
        else{
            for (int i = 0; i < URL->getNumber(); i++){
                if((p=strstr(URL->getType(i),"HK")))
                    ui->CorsSourceList->addItem(URL->getType(i));
            }
        }
    }
    else if ((strstr(sourceurl,"OTHERS"))){
        for (int i = 0; i < URL->getNumber();i++){
            ui->OthersSourceList->addItem(URL->getType(i));
        }
    }

    delete [] sourceurl;
    delete URL;
}
//---------------------------------------------------------------------------
void MainForm::BtnProductAddClick()
{
    if (!ui->ProductsDownloadList->count()){
        for (int i = 0; i < ui->ProductsSourceList->count();i++){
            if (ui->ProductsSourceList->item(i)->isSelected()){
                ui->ProductsDownloadList->addItem(ui->ProductsSourceList->item(i)->text());
                ui->ProductsSourceList->item(i)->setSelected(false);
            }
        }
    }
    else{
        for (int i = 0; i < ui->ProductsSourceList->count();i++){
            if (ui->ProductsSourceList->item(i)->isSelected()){
                for (int j =0; j < ui->ProductsDownloadList->count(); j++){
                    if (QString(ui->ProductsSourceList->item(i)->text()).compare(
                                QString(ui->ProductsDownloadList->item(j)->text()))==0)
                        break;
                    else{
                        if (j==ui->ProductsDownloadList->count()-1){
                            ui->ProductsDownloadList->addItem(ui->ProductsSourceList->item(i)->text());
                            ui->ProductsSourceList->item(i)->setSelected(false);
                        }
                        else
                            continue;
                    }

                }
            }
        }
    }

}
//---------------------------------------------------------------------------
void MainForm::BtnCorsAddClick()
{
    if (!ui->CorsDownloadList->count()){
        for (int i = 0;i<ui->CorsSourceList->count();i++){
            if (ui->CorsSourceList->item(i)->isSelected()){
                ui->CorsDownloadList->addItem(
                            ui->CorsSourceList->item(i)->text());
                ui->CorsSourceList->item(i)->setSelected(false);
            }
        }
    }
    else{
        for (int i = 0;i<ui->CorsSourceList->count();i++){
            if (ui->CorsSourceList->item(i)->isSelected()){
                for (int j=0;j<ui->CorsDownloadList->count();j++){
                    if (ui->CorsSourceList->item(i)->text().compare(
                                ui->CorsDownloadList->item(j)->text())==0)
                        break;
                    else{
                        if (j==ui->CorsDownloadList->count()-1){
                            ui->CorsDownloadList->addItem(
                                        ui->CorsSourceList->item(i)->text());
                            ui->CorsSourceList->item(i)->setSelected(false);
                        }
                    }
                }
            }
        }
    }
}
//---------------------------------------------------------------------------
void MainForm::BtnCorsRemoveClick()
{
    for (int i = ui->CorsDownloadList->count()-1;i>=0;i--){
        if (ui->CorsDownloadList->item(i)->isSelected())
            ui->CorsDownloadList->takeItem(i);
    }
}
//---------------------------------------------------------------------------
void MainForm::BtnLoadCorsListClick()
{
    QString dir = ui->CorsListDir->currentText();

    dir = QDir::toNativeSeparators(QFileDialog::getOpenFileName
                                   (this, tr("open...")));
    ui->CorsListDir->insertItem(0,dir);
    ui->CorsListDir->setCurrentIndex(0);
}
//---------------------------------------------------------------------------
void MainForm::BtnProductRemoveClick()
{
    for(int i = ui->ProductsDownloadList->count()-1; i>=0; i--){
        if (ui->ProductsDownloadList->item(i)->isSelected())
            ui->ProductsDownloadList->takeItem(i);
    }
}
//---------------------------------------------------------------------------
void MainForm::updateEnabled()
{
    /*Local dir enabled--------------------------------------------*/
    ui->LocalDir->setEnabled(ui->cBoxLocalDir->isChecked());
    ui->BtnLocalDir->setEnabled(ui->cBoxLocalDir->isChecked());
    /*option table enabled----------------------------------------*/
    ui->tbData->setEnabled(ui->rBtnCDDIS->isChecked() || ui->rBtnWHU->isChecked());
    ui->tbProducts->setEnabled(ui->rBtnCDDIS->isChecked() || ui->rBtnWHU->isChecked()
                               || ui->rBtniGMAS->isChecked());
    ui->tbCors->setEnabled(ui->rBtnCORS->isChecked());
    ui->tbOthers->setEnabled(ui->rBtnOTHERS->isChecked());
    /*table data enabled-----------------------------------------*/
    ui->ObsType->setEnabled(ui->cBoxOBS->isChecked());
    ui->NavType->setEnabled(ui->cBoxNav->isChecked());
    ui->Sta_NavType->setEnabled(ui->cBoxSTA_NAV->isChecked());
    ui->ListDir->setEnabled(ui->cBoxStaList->isChecked());
    ui->BtnListDir->setEnabled(ui->cBoxStaList->isChecked());
    ui->List->setEnabled(!ui->cBoxStaList->isChecked());
    ui->panelData2->setEnabled(ui->cBoxOBS->isChecked() || ui->cBoxSTA_NAV->isChecked());
    ui->panelData3->setEnabled(ui->cBoxOBS->isChecked() || ui->cBoxSTA_NAV->isChecked());

}
//---------------------------------------------------------------------------
void MainForm::BtnAddListClick()
{

    if (!ui->DataList->count()){
        if (!QString(ui->ObsType->currentText()).isEmpty()){
            ui->DataList->addItem(QString(ui->ObsType->currentText()));
        }
        if (!QString(ui->NavType->currentText()).isEmpty()){
            ui->DataList->addItem(QString(ui->NavType->currentText()));
        }
        if (!QString(ui->Sta_NavType->currentText()).isEmpty()){
            ui->DataList->addItem(QString(ui->Sta_NavType->currentText()));
        }
    }
    else{
        if (!QString(ui->ObsType->currentText()).isEmpty()){
            for (int i=0; i < ui->DataList->count();i++){
                if (QString(ui->DataList->item(i)->text()).compare(
                            QString(ui->ObsType->currentText()))==0)
                    break;
                else{
                    if (i==ui->DataList->count()-1){
                        ui->DataList->addItem(ui->ObsType->currentText());
                    }
                    else
                        continue;
                }

            }
        }

        if (!ui->NavType->currentText().isEmpty()){
            for (int i=0; i < ui->DataList->count();i++){
                if (QString(ui->DataList->item(i)->text()).compare(
                            QString(ui->NavType->currentText()))==0)
                    break;
                 else{
                    if (i==ui->DataList->count()-1){
                        ui->DataList->addItem(ui->NavType->currentText());
                    }
                    else
                        continue;
                }

            }
        }

        if (!ui->Sta_NavType->currentText().isEmpty()){
            for (int i=0; i < ui->DataList->count();i++){
                if (QString(ui->DataList->item(i)->text()).compare(
                            QString(ui->Sta_NavType->currentText()))==0)
                    break;
                else{
                    if (i==ui->DataList->count()-1){
                        ui->DataList->addItem(ui->Sta_NavType->currentText());
                    }
                    else
                        continue;
                }

            }
        }
    }

}
//---------------------------------------------------------------------------
void MainForm::BtnRemoveListClick()
{
    for (int i = ui->DataList->count()-1; i >= 0; i--){
        if (ui->DataList->item(i)->isSelected()){
                ui->DataList->takeItem(i);
        }
    }
}
//---------------------------------------------------------------------------
void MainForm::BtnOthersAddClick()
{
    if (!ui->OthersDownloadList->count()){
        for (int i = 0;i < ui->OthersSourceList->count();i++){
            if (ui->OthersSourceList->item(i)->isSelected()){
                ui->OthersDownloadList->addItem(ui->OthersSourceList->item(i)->text());
                ui->OthersSourceList->item(i)->setSelected(false);
            }
        }
    }
    else{
        for (int i = 0; i < ui->OthersSourceList->count(); i++){
            for  (int j = 0; j< ui->OthersDownloadList->count(); j++){
                if (ui->OthersSourceList->item(i)->text().compare(
                            ui->OthersDownloadList->item(j)->text())==0)
                    break;
                else{
                    if (j == ui->OthersDownloadList->count()-1){
                        ui->OthersDownloadList->addItem(ui->OthersSourceList->item(i)->text());
                        ui->OthersSourceList->item(i)->setSelected(false);
                    }
                }
            }
        }
    }
}
//----------------------------------------------------------------------------
void MainForm::BtnOthersRemoveClick()
{
    for (int i = ui->OthersDownloadList->count()-1;i>=0;i--){
        if (ui->OthersDownloadList->item(i)->isSelected()){
            ui->OthersDownloadList->takeItem(i);
        }
    }
}
//---------------------------------------------------------------------------
void MainForm::BtnLocalDirClick()
{

    QString dir = ui->LocalDir->currentText();

    dir = QDir::toNativeSeparators(QFileDialog::getExistingDirectory(this, tr("Local Directory"), dir));
    ui->LocalDir->insertItem(0,dir);
    ui->LocalDir->setCurrentIndex(0);

}
//---------------------------------------------------------------------------
void MainForm::BtnAboutClick()
{
    aboutdlg aboutDialog(this);
    QString prog = PRGNAME;

    aboutDialog.About=prog;
    aboutDialog.exec();
}
//---------------------------------------------------------------------------
void MainForm::BtnTrayClick()
{
    setVisible(false);
    TrayIcon.setVisible(true);
}
//---------------------------------------------------------------------------
void MainForm::TrayIconActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason != QSystemTrayIcon::DoubleClick &&
            reason != QSystemTrayIcon::Trigger) return;

    setVisible(true);
    TrayIcon.setVisible(false);
}
//-----------------------------------------------------------------------------
void MainForm::PanelEnable(int ena)
{
    ui->tbData->setEnabled(ena);
    ui->panelOpt->setEnabled(ena);
    ui->BtnDownload->setEnabled(ena);
    ui->BtnAbout->setEnabled(ena);
    ui->BtnLog->setEnabled(ena);
}
//-----------------------------------------------------------------------------
void MainForm::BtnListDirClick()
{

    QString dir = ui->ListDir->currentText();

    dir = QDir::toNativeSeparators(QFileDialog::getOpenFileName
                                   (this, tr("Open...")));
    ui->ListDir->insertItem(0,dir);
    ui->ListDir->setCurrentIndex(0);

}
int  MainForm::selectStas(char **stas)
{
    QString file,staslist;
    int nsta=0;

    if (ui->cBoxStaList->isChecked()){
        file = ui->ListDir->currentText();
        nsta=readStasFile(qPrintable(file),stas);
    }
    else if (ui->rBtnCORS->isChecked())
    {
        file = ui->CorsListDir->currentText();
        nsta=readStasFile(qPrintable(file),stas);
    }
    else if (!ui->List->text().isEmpty()){
       staslist = ui->List->text();
       nsta=readStasList(qPrintable(staslist),stas);
    }

    return nsta;
}
//---------------------------------------------------------------------------------
time_t MainForm::getTime(QDateTime time)
{
    time_t T;
    T=static_cast<time_t>(time.toTime_t());
    return T;
}
//---------------------------------------------------------------------------------
int MainForm::getDataType(char **type)
{
    int n=0;
    if (ui->rBtnCDDIS->isChecked() || ui->rBtnWHU->isChecked()){
        if (ui->DataList->count()){
            for (int i = 0; i < ui->DataList->count();i++){
               strcpy(type[n],qPrintable(ui->DataList->item(i)->text()));
               type[n++][ui->DataList->item(i)->text().length()]='\0';
            }
        }
        if (ui->ProductsDownloadList->count()){
            for(int i = 0; i < ui->ProductsDownloadList->count(); i++){
                strcpy(type[n],qPrintable(ui->ProductsDownloadList->item(i)->text()));
                type[n++][ui->ProductsDownloadList->item(i)->text().length()]='\0';
            }
        }
    }
    else if (ui->rBtnCORS->isChecked()){
        if (ui->CorsDownloadList->count()){
            for (int i = 0; i < ui->CorsDownloadList->count();i++){
                strcpy(type[n],qPrintable(ui->CorsDownloadList->item(i)->text()));
                type[n++][ui->CorsDownloadList->item(i)->text().length()]='\0';
            }
        }
    }
    else if (ui->rBtniGMAS->isChecked()){
        if (ui->ProductsDownloadList->count()){
            for(int i = 0; i < ui->ProductsDownloadList->count(); i++){
                strcpy(type[n],qPrintable(ui->ProductsDownloadList->item(i)->text()));
                type[n++][ui->ProductsDownloadList->item(i)->text().length()]='\0';
            }
        }
    }
    else if (ui->rBtnOTHERS->isChecked()){
        if (ui->OthersDownloadList->count()){
            for (int i = 0; i < ui->OthersDownloadList->count(); i++){
                strcpy(type[n],qPrintable(ui->OthersDownloadList->item(i)->text()));
                type[n++][ui->OthersDownloadList->item(i)->text().length()]='\0';
            }
        }
    }
    return n;
}
//-------------------------------------------------------------------------------------------
void MainForm::selectUrls(char **type, char **urls, char **locals,const int number)
{
    url_c *URL; URL = new url_c();
    char sourceUrls[32] = {""};
    int n;

    if (ui->rBtnCDDIS->isChecked()){
        strcpy(sourceUrls,"CDDIS");
    }
    else if (ui->rBtnWHU->isChecked()){
        strcpy(sourceUrls,"WHU");
    }
    else if (ui->rBtnCORS->isChecked()){
        strcpy(sourceUrls,"CORS");
    }
    else if (ui->rBtniGMAS->isChecked()){
        strcpy(sourceUrls,"iGMAS");
    }
    else if (ui->rBtnOTHERS->isChecked()){
        strcpy(sourceUrls,"OTHERS");
    }

    n=URL->getUrls(sourceUrls,type,urls,locals,number);
    delete URL;
}
//-------------------------------------------------------------------------------------------
void MainForm::BtnDownloadClick()
{

    char *type[MAXURLS_SEL];
    for (int i=0;i<MAXURLS_SEL;i++){
        type[i] = new char [32];
        type[i][0] = '\0';
    }
    QDateTime ts(ui->dayTime1->dateTime());
    QDateTime te(ui->dayTime2->dateTime());

    if (ui->BtnDownload->text().remove('&') == tr("Abort")){
        ui->BtnDownload->setEnabled(false);
        abortf = 1;
        return;
    }

    thread = new DownloadThread(this,LogFile);

    thread->ts   = getTime(ts);
    thread->te   = getTime(te);
    thread->nsta = selectStas(thread->stas);
    thread->nurl = getDataType(type);
    selectUrls(type,thread->urls,thread->localdir,thread->nurl);

    if ((thread->ts-thread->te)>0.0 || thread->nurl<=0){
        ui->MsggLabel2->setText(tr("no download data"));
        return;
    }

    if (ui->cBoxLocalDir->isChecked())
        strcpy(thread->dir,qPrintable(ui->LocalDir->currentText()));

    if (!ui->cBoxSkip->isChecked()) thread->opts |= DLOPT_FORCE;
    if (!ui->cBoxUnzip->isChecked()) thread->opts |= DLOPT_KEEPCMP;

    abortf = 0;
    PanelEnable(0);
    ui->BtnDownload->setEnabled(true);
    ui->BtnDownload->setText(tr("Abort"));
    ui->MsggLabel2->setText("");

    connect(thread,SIGNAL(finished()),this,SLOT(DownloadFinished()));

    Timer.start(100);

    thread->start();

    for (int i = 0;i<MAXURLS_SEL;i++){
        delete [] type[i];type[i]=NULL;
    }

}
//-------------------------------------------------------------------------------------------
void MainForm::DownloadFinished()
{
    PanelEnable(1);
    updateEnabled();
    Timer.stop();

    if (ui->LocalDir->isEnabled()) AddHist(ui->LocalDir);

    ui->BtnDownload->setText(tr("&Download"));
    ui->MsggLabel2->setText(thread->msg);

    updateEnabled();
    delete thread;
}
//--------------------------------------------------------------------------------------------
void MainForm::BtnLogClick()
{
    viewerDialog = new viewerDlg(this);

    QString logPath;
    QString logFile;
    if (ui->cBoxLocalDir->isChecked()){
        logPath = ui->LocalDir->currentText();
        logFile = QFileDialog::getOpenFileName(this,tr("open logFile"),logPath,tr("*.log"));
    }
    else{
        logPath = "c:\\GNSS_DATA\\";
        logFile = QFileDialog::getOpenFileName(this,tr("open logFile"),logPath,tr("*.log"));
    }

    viewerDialog->Read(logFile);
    viewerDialog->exec();
}
//--------------------------------------------------------------------------------------------
void MainForm::TimerTimer()
{
    ui->lbImage->setPixmap(Images[TimerCnt % 8]);
    qApp->processEvents();
    TimerCnt++;
}
// --------------------------------------------------------------------------
void MainForm::AddHist(QComboBox *combo)
{
    QString hist = combo->currentText();

    if (hist == "") return;
    int i = combo->currentIndex();
    combo->removeItem(i);
    combo->insertItem(0, hist);
    for (int i = combo->count() - 1; i >= MAX_HIST; i--) combo->removeItem(i);
    combo->setCurrentIndex(0);
}
